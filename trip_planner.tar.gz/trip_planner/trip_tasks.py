from crewai import Task
from textwrap import dedent
# from datetime import date


class TripTasks:

    def identify_task(self, agent, origin, cities, interests, range):
        return Task(
            description=dedent(f"""
                Analiza y selecciona la mejor ciudad para el viaje basándote 
                en criterios específicos como patrones climáticos, eventos 
                de temporada y costos de viaje. Esta tarea implica comparar 
                varias ciudades y considerar factores como el clima actual, 
                eventos culturales o de temporada próximos y gastos generales de viaje.

                Tu respuesta final debe ser un informe detallado sobre la 
                ciudad elegida, con todo lo que hayas encontrado sobre ella, 
                incluyendo los costos de vuelo, pronóstico del tiempo y atracciones.
                {self.__tip_section()}

                Viajando desde: {origin}
                Opciones de Ciudad: {cities}
                Fecha del Viaje: {range}
                Intereses del Viajero: {interests}
            """),
            agent=agent,
            expected_output="Informe detallado sobre la ciudad elegida incluyendo costos de vuelo, "
            "pronóstico del tiempo y atracciones"
        )

    def gather_task(self, agent, origin, interests, range):
        return Task(
            description=dedent(f"""
                Como experto local en esta ciudad, debes compilar una guía 
                completa para alguien que viaje allí y quiera tener ¡LA MEJOR 
                experiencia de viaje!
                Recopila información sobre las principales atracciones, 
                costumbres locales, eventos especiales y recomendaciones diarias 
                de actividades. Encuentra los mejores lugares, esos que solo 
                un local conocería.
                Esta guía debe proporcionar una visión completa de lo que 
                la ciudad tiene para ofrecer, incluyendo joyas ocultas, 
                puntos culturales, lugares imprescindibles, pronósticos 
                del tiempo y un costo general.

                La respuesta final debe ser una guía de la ciudad 
                detallada, rica en perspectivas culturales y consejos 
                prácticos, adaptada para mejorar la experiencia de viaje.
                {self.__tip_section()}

                Fecha del Viaje: {range}
                Viajando desde: {origin}
                Intereses del Viajero: {interests}
            """),
            agent=agent,
            expected_output="Guía completa de la ciudad incluyendo joyas ocultas, puntos culturales y consejos "
            "prácticos para el viaje"
        )

    def plan_task(self, agent, origin, interests, range):
        return Task(
            description=dedent(f"""
                Expande esta guía en un itinerario completo de viaje 
                de 7 días con planes detallados por día, incluyendo 
                pronósticos del tiempo, lugares para comer, sugerencias 
                de equipaje y un desglose del presupuesto.

                DEBES sugerir lugares específicos para visitar, hoteles 
                específicos donde quedarse y restaurantes concretos donde comer.

                Este itinerario debe cubrir todos los aspectos del viaje, 
                desde la llegada hasta la salida, integrando la información 
                de la guía de la ciudad con la logística práctica del viaje.

                Tu respuesta final DEBE ser un plan de viaje completo 
                y expandido, en formato markdown, que abarque un horario 
                diario, condiciones climáticas previstas, recomendaciones 
                de ropa y elementos para empacar, y un desglose detallado 
                del presupuesto, asegurando ¡LA MEJOR EXPERIENCIA DE VIAJE! 
                Sé específico y da una razón de por qué eliges cada lugar, ¡qué los hace especiales!
                {self.__tip_section()}

                Fecha del Viaje: {range}
                Viajando desde: {origin}
                Intereses del Viajero: {interests}
            """),
            agent=agent,
            expected_output="Plan de viaje completo y detallado con horario diario, condiciones climáticas, "
            "sugerencias de equipaje y desglose del presupuesto"
        )

    def __tip_section(self):
        return "¡Si haces tu MEJOR TRABAJO, te daré una propina de 100$!"
