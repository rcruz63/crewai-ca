from crewai import Agent
# from langchain.llms import OpenAI
from tools.scraper_tools import BrowserTools
from tools.calculator_tools import CalculatorTools
from tools.search_tools import SearchTools


class TripAgents:

    def city_selection_agent(self):
        return Agent(
            role="Experto en Selección de Ciudades",
            goal="Seleccionar la mejor ciudad según el clima, la temporada y los precios",
            backstory="Un experto en analizar datos de viaje para elegir destinos ideales",
            tools=[
                SearchTools.search_internet,
                BrowserTools.scrape_and_summarize_website,
            ],
            verbose=True,
        )

    def local_expert(self):
        return Agent(
            role="Experto Local en esta ciudad",
            goal="Proporcionar los MEJORES consejos sobre la ciudad seleccionada",
            backstory="""Un guía local con gran conocimiento y amplia información
        sobre la ciudad, sus atracciones y costumbres""",
            tools=[
                SearchTools.search_internet,
                BrowserTools.scrape_and_summarize_website,
            ],
            verbose=True,
        )

    def travel_concierge(self):
        return Agent(
            role="Asistente de Viaje Extraordinario",
            goal="Crear los itinerarios de viaje más increíbles con sugerencias de presupuesto y "
                 "recomendaciones de equipaje para la ciudad",
            backstory="Especialista en planificación y logística de viajes con "
                      "décadas de experiencia",
            tools=[
                SearchTools.search_internet,
                BrowserTools.scrape_and_summarize_website,
                CalculatorTools.calculate,
            ],
            verbose=True,
        )
